import { readFile, writeFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import path from 'node:path';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const sourceFiles = ['src/data.js', 'src/i18n.js', 'src/core.js', 'src/views.js', 'src/app.js'];
let html = await readFile(path.join(root, 'index.html'), 'utf8');
const css = await readFile(path.join(root, 'styles.css'), 'utf8');
html = html.replace('<link rel="stylesheet" href="styles.css">', '<style>\n' + css + '\n</style>');
for (const source of sourceFiles) {
  const contents = await readFile(path.join(root, source), 'utf8');
  const tag = '<script src="' + source + '"></script>';
  if (!html.includes(tag)) throw new Error('Missing script tag for ' + source);
  html = html.replace(tag, '<script>\n' + contents + '\n</script>');
}
await writeFile(path.join(root, 'standalone.html'), html, 'utf8');
process.stdout.write('Built standalone.html with ' + sourceFiles.length + ' local scripts.\n');
