(function (global) {
  'use strict';
  const STORAGE_KEY = 'nexus-dataops-workspace-v1';
  const clone = function (value) { return JSON.parse(JSON.stringify(value)); };
  function validateState(value) {
    if (!value || typeof value !== 'object' || Array.isArray(value)) throw new TypeError('Workspace must be an object.');
    ['pipelines', 'runs', 'connectors', 'contracts', 'rules', 'alerts', 'assets', 'events'].forEach(function (key) {
      if (!Array.isArray(value[key])) throw new TypeError('Workspace field ' + key + ' must be an array.');
    });
    if (!value.settings || typeof value.settings !== 'object') throw new TypeError('Workspace settings are missing.');
    if (!['en', 'zh'].includes(value.settings.language)) value.settings.language = 'en';
    value.pipelines.forEach(function (pipeline) {
      if (!pipeline.id || !pipeline.name || !Array.isArray(pipeline.nodes)) throw new TypeError('A pipeline record is malformed.');
      if (!['active', 'paused'].includes(pipeline.status)) pipeline.status = 'paused';
    });
    return value;
  }
  function migrate(value) {
    if (!value || typeof value !== 'object') throw new TypeError('Backup format is invalid.');
    if (Number(value.schemaVersion || 0) > 1) throw new RangeError('This backup was created by a newer Nexus version.');
    value.schemaVersion = 1;
    value.settings = value.settings || clone(global.NexusData.initial.settings);
    value.metrics = value.metrics || clone(global.NexusData.initial.metrics);
    ['runs', 'connectors', 'contracts', 'rules', 'alerts', 'assets', 'events'].forEach(function (key) { value[key] = value[key] || []; });
    return validateState(value);
  }
  function load(storage) {
    const fallback = clone(global.NexusData.initial);
    try {
      const raw = storage.getItem(STORAGE_KEY);
      return raw ? migrate(JSON.parse(raw)) : fallback;
    } catch (error) {
      fallback.loadWarning = error instanceof Error ? error.message : String(error);
      return fallback;
    }
  }
  function save(storage, state) {
    const clean = clone(state);
    delete clean.loadWarning;
    storage.setItem(STORAGE_KEY, JSON.stringify(clean));
  }
  function number(value, digits) { return new Intl.NumberFormat(undefined, { maximumFractionDigits: digits || 0 }).format(Number(value) || 0); }
  function time(value) {
    if (!value) return '—';
    const date = new Date(value);
    return Number.isNaN(date.getTime()) ? '—' : new Intl.DateTimeFormat(undefined, { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }).format(date);
  }
  function makeId(prefix, records) {
    const max = records.reduce(function (highest, record) {
      return Math.max(highest, Number(String(record.id).match(/\d+/) && String(record.id).match(/\d+/)[0] || 0));
    }, 0);
    return prefix + '-' + String(max + 1).padStart(4, '0');
  }
  function addEvent(state, kind, text, meta) {
    state.events.unshift({ id: makeId('EV', state.events), kind: kind, text: text, meta: meta || time(new Date()) });
    state.events = state.events.slice(0, 120);
  }
  function startRun(state, pipelineId) {
    const pipeline = state.pipelines.find(function (item) { return item.id === pipelineId; });
    if (!pipeline) throw new RangeError('Pipeline not found.');
    if (pipeline.status !== 'active') throw new Error('This pipeline is paused. Resume it before running.');
    if (state.runs.some(function (run) { return run.pipelineId === pipelineId && run.status === 'running'; })) throw new Error('A run is already in progress.');
    const run = { id: makeId('RUN', state.runs), pipelineId: pipelineId, status: 'running', startedAt: new Date().toISOString(), duration: 0, recordsIn: 0, recordsOut: 0, bytes: 0, retries: 0, quality: 0, message: 'Workflow is executing in the local simulator.' };
    state.runs.unshift(run);
    state.runs = state.runs.slice(0, 300);
    pipeline.lastRun = run.startedAt;
    pipeline.lastStatus = 'running';
    addEvent(state, 'running', pipeline.name + ' started', pipeline.id + ' / manual run');
    return run;
  }
  function finishRun(state, runId) {
    const run = state.runs.find(function (item) { return item.id === runId; });
    if (!run || run.status !== 'running') throw new RangeError('Active run not found.');
    const pipeline = state.pipelines.find(function (item) { return item.id === run.pipelineId; });
    if (!pipeline) throw new RangeError('Pipeline for run not found.');
    const failed = pipeline.id === 'PL-0994';
    const warning = pipeline.id === 'PL-1038';
    const status = failed ? 'failed' : warning ? 'warning' : 'success';
    const count = Math.max(480, Math.round(pipeline.records * (0.14 + state.runs.length % 5 * 0.012)));
    run.status = status;
    run.duration = Math.max(12, Math.round(pipeline.avgDuration * (0.8 + state.runs.length % 6 * 0.055)));
    run.recordsIn = count;
    run.recordsOut = Math.round(count * (failed ? 0.87 : warning ? 0.9968 : 1));
    run.bytes = run.recordsOut * 220;
    run.retries = failed ? 2 : warning ? 1 : 0;
    run.quality = Math.round((pipeline.successRate - (failed ? 8 : warning ? 1.2 : 0)) * 10) / 10;
    run.message = failed ? 'Required supplier SKU is missing in sampled rows; affected records were quarantined.' : warning ? 'Duplicate inventory keys were quarantined; the remaining batch completed.' : 'Checkpoint committed; contract checks passed for this simulated batch.';
    pipeline.lastStatus = status;
    pipeline.lastRun = new Date().toISOString();
    pipeline.records += run.recordsOut;
    state.metrics.monthlyRuns += 1;
    addEvent(state, status, pipeline.name + (failed ? ' failed' : warning ? ' completed with warnings' : ' completed'), run.id + ' / ' + number(run.recordsOut) + ' rows');
    if (status !== 'success') {
      state.alerts.unshift({ id: makeId('ALT', state.alerts), title: failed ? 'Pipeline run failed validation' : 'Rows were quarantined during replay', detail: run.message, severity: failed ? 'critical' : 'warning', source: pipeline.id + ' / ' + run.id, time: new Date().toISOString(), status: 'open', owner: pipeline.owner });
      state.alerts = state.alerts.slice(0, 150);
    }
    return run;
  }
  function evaluateRules(state) {
    let passed = 0;
    let failed = 0;
    state.rules.filter(function (rule) { return rule.active; }).forEach(function (rule) {
      rule.passRate >= rule.threshold ? passed++ : failed++;
      rule.checked += Math.max(120, Math.round(rule.checked * 0.03));
      rule.lastEvaluated = new Date().toISOString();
    });
    state.metrics.qualityScore = state.rules.filter(function (rule) { return rule.active; }).reduce(function (sum, rule, _, list) { return sum + rule.passRate / list.length; }, 0);
    addEvent(state, failed ? 'warning' : 'success', 'Quality evaluation completed', passed + ' passed / ' + failed + ' below threshold');
    return { passed: passed, failed: failed };
  }
  function createPipeline(state, input) {
    const name = String(input.name || '').trim().slice(0, 80);
    if (name.length < 3) throw new TypeError('Pipeline name must contain at least 3 characters.');
    const source = state.connectors.find(function (item) { return item.id === input.source && item.kind === 'source'; });
    const target = state.connectors.find(function (item) { return item.id === input.target && item.kind === 'target'; });
    if (!source || !target) throw new RangeError('Choose an available source and destination.');
    const pipeline = { id: makeId('PL', state.pipelines), name: name, domain: String(input.domain || 'Platform').trim(), owner: 'Workspace owner', source: source.id, target: target.id, cadence: String(input.cadence || 'Manual'), status: 'active', health: 'healthy', successRate: 100, avgDuration: 45, records: 0, lastRun: null, lastStatus: 'success', nodes: [{ label: source.name, kind: 'source' }, { label: 'Map and validate', kind: 'transform' }, { label: target.name, kind: 'target' }] };
    state.pipelines.unshift(pipeline);
    addEvent(state, 'success', name + ' added to the workspace', pipeline.id);
    return pipeline;
  }
  function summary(state) {
    const active = state.pipelines.filter(function (item) { return item.status === 'active'; });
    const recent = state.runs.filter(function (run) { return Date.now() - new Date(run.startedAt).getTime() < 86400000; });
    const settled = recent.filter(function (run) { return run.status !== 'running'; });
    const ok = settled.filter(function (run) { return run.status === 'success'; }).length;
    return { active: active.length, successRate: settled.length ? Math.round(ok / settled.length * 1000) / 10 : 100, recordsToday: recent.reduce(function (sum, run) { return sum + run.recordsOut; }, 0), pending: state.alerts.filter(function (alert) { return alert.status !== 'resolved'; }).length, failedRuns: settled.filter(function (run) { return run.status === 'failed'; }).length, running: state.runs.filter(function (run) { return run.status === 'running'; }).length };
  }
  function download(name, contents, type) {
    const blob = new Blob([contents], { type: type || 'application/json' });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement('a');
    anchor.href = url;
    anchor.download = name;
    anchor.click();
    global.setTimeout(function () { URL.revokeObjectURL(url); }, 1200);
  }
  global.NexusCore = Object.freeze({ STORAGE_KEY: STORAGE_KEY, clone: clone, validateState: validateState, migrate: migrate, load: load, save: save, number: number, time: time, makeId: makeId, addEvent: addEvent, startRun: startRun, finishRun: finishRun, evaluateRules: evaluateRules, createPipeline: createPipeline, summary: summary, download: download });
})(window);
