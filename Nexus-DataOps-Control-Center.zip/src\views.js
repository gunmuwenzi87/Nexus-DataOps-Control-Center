(function (global) {
  'use strict';
  const esc = function (value) { return String(value == null ? '' : value).replace(/[&<>"']/g, function (char) { return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[char]; }); };
  function render(state, ui) {
    const language = ui.language || state.settings.language || 'en';
    const t = function (key) { return global.NexusI18n.translate(language, key); };
    const route = ui.route || 'overview';
    const titleKey = ({ overview: 'overview', pipelines: 'pipelines', runs: 'runs', quality: 'quality', lineage: 'lineage', connectors: 'connectors', alerts: 'alerts', catalog: 'catalog', settings: 'settings' })[route] || 'overview';
    const descKey = ({ overview: 'overviewDesc', pipelines: 'pipelineDesc', runs: 'runsDesc', quality: 'qualityDesc', lineage: 'lineageDesc', connectors: 'connectorsDesc', alerts: 'alertsDesc', catalog: 'catalogDesc', settings: 'settingsDesc' })[route] || 'overviewDesc';
    const summary = global.NexusCore.summary(state);
    const icons = { overview: '◫', pipelines: '⌘', runs: '◷', quality: '◈', lineage: '⌁', connectors: '⎇', alerts: '△', catalog: '▤', settings: '⚙' };
    const escAttr = esc;
    function button(label, action, id, style) {
      return '<button type="button" class="btn ' + (style || 'btn-quiet') + '" data-action="' + escAttr(action) + '"' + (id ? ' data-id="' + escAttr(id) + '"' : '') + '>' + esc(label) + '</button>';
    }
    function badge(value) {
      const normalized = String(value || 'healthy').toLowerCase();
      const key = ({ healthy: 'healthy', attention: 'attentionStatus', active: 'active', paused: 'paused', success: 'success', warning: 'warning', failed: 'failed', running: 'running', connected: 'connected', open: 'open', acknowledged: 'acknowledged', resolved: 'resolved', critical: 'critical', info: 'success' })[normalized] || normalized;
      return '<span class="badge badge-' + escAttr(normalized) + '"><i></i>' + esc(t(key)) + '</span>';
    }
    function sectionHead(eyebrow, title, description, right) {
      return '<div class="section-head"><div><div class="eyebrow">' + esc(eyebrow) + '</div><h2>' + esc(title) + '</h2><p>' + esc(description) + '</p></div>' + (right || '') + '</div>';
    }
    function pipelineRows(items) {
      if (!items.length) return '<tr><td colspan="6" class="empty-cell">' + esc(t('noResults')) + '</td></tr>';
      return items.map(function (item) {
        const currentRun = state.runs.find(function (run) { return run.pipelineId === item.id && run.status === 'running'; });
        const domain = String(item.domain || 'Platform');
        return '<tr><td><div class="primary-cell"><span class="table-icon">' + esc(domain.slice(0, 1)) + '</span><div><strong>' + esc(item.name) + '</strong><small>' + esc(item.id) + ' · ' + esc(domain) + '</small></div></div></td><td>' + badge(item.health) + '</td><td>' + esc(item.owner) + '</td><td>' + esc(item.cadence) + '</td><td>' + esc(global.NexusCore.number(item.successRate, 1)) + '%</td><td class="table-actions">' + (currentRun ? badge('running') : button(t('runNow'), 'run-pipeline', item.id, 'btn-mini btn-primary')) + button(item.status === 'active' ? t('pause') : t('resume'), 'toggle-pipeline', item.id, 'btn-mini') + '</td></tr>';
      }).join('');
    }
    function runRows(items) {
      if (!items.length) return '<tr><td colspan="6" class="empty-cell">' + esc(t('noRuns')) + '</td></tr>';
      return items.map(function (run) {
        const pipeline = state.pipelines.find(function (item) { return item.id === run.pipelineId; });
        return '<tr class="clickable-row" data-action="open-run" data-id="' + escAttr(run.id) + '"><td><div class="primary-cell"><span class="run-dot dot-' + escAttr(run.status) + '"></span><div><strong>' + esc(pipeline ? pipeline.name : run.pipelineId) + '</strong><small>' + esc(run.id) + '</small></div></div></td><td>' + badge(run.status) + '</td><td>' + esc(global.NexusCore.time(run.startedAt)) + '</td><td>' + esc(run.duration ? run.duration + ' ' + t('sec') : '—') + '</td><td>' + esc(global.NexusCore.number(run.recordsOut)) + '</td><td>' + esc(run.quality ? global.NexusCore.number(run.quality, 1) + '%' : '—') + '</td></tr>';
      }).join('');
    }
    function pipelineTable(items) {
      return '<div class="table-wrap"><table><thead><tr><th>' + esc(t('pipeline')) + '</th><th>' + esc(t('status')) + '</th><th>' + esc(t('owner')) + '</th><th>' + esc(t('cadence')) + '</th><th>' + esc(t('successRate')) + '</th><th>' + esc(t('actions')) + '</th></tr></thead><tbody>' + pipelineRows(items) + '</tbody></table></div>';
    }
    function runTable(items) {
      return '<div class="table-wrap"><table><thead><tr><th>' + esc(t('pipeline')) + '</th><th>' + esc(t('status')) + '</th><th>' + esc(t('started')) + '</th><th>' + esc(t('duration')) + '</th><th>' + esc(t('records')) + '</th><th>' + esc(t('qualityScore')) + '</th></tr></thead><tbody>' + runRows(items) + '</tbody></table></div>';
    }
    function metric(label, value, suffix, trend, icon) {
      return '<article class="metric-card"><div class="metric-top"><span>' + esc(label) + '</span><span class="metric-icon">' + icon + '</span></div><div class="metric-value">' + esc(value) + '<small>' + esc(suffix || '') + '</small></div><div class="metric-foot"><span class="trend-mark">↗</span>' + esc(trend || '') + '</div></article>';
    }
    function overview() {
      const flow = state.pipelines.filter(function (p) { return p.status === 'active'; }).slice(0, 4).map(function (p) {
        return '<div class="flow-row"><span class="flow-name">' + esc(p.name) + '</span><div class="flow-track"><i style="width:' + Math.min(100, Math.max(18, p.successRate)) + '%"></i></div><span class="flow-value">' + esc(global.NexusCore.number(p.successRate, 1)) + '%</span>' + badge(p.health) + '</div>';
      }).join('');
      const events = state.events.slice(0, 5).map(function (event) {
        return '<div class="event-row"><span class="event-mark event-' + escAttr(event.kind) + '"></span><div><strong>' + esc(event.text) + '</strong><small>' + esc(event.meta) + '</small></div></div>';
      }).join('');
      return '<div class="metrics-grid">' +
        metric(t('activePipelines'), summary.active, t('pipelines'), '+2.4% this week', '⌘') +
        metric(t('successRate'), global.NexusCore.number(summary.successRate, 1), '%', t('timezone'), '↗') +
        metric(t('recordsProcessed'), global.NexusCore.number(summary.recordsToday), t('rows'), '+12.8% vs yesterday', '▤') +
        metric(t('dataQuality'), global.NexusCore.number(state.metrics.qualityScore, 1), '%', t('activeRules'), '◈') +
        '</div><div class="dashboard-grid"><section class="panel panel-flow">' +
        sectionHead(t('healthOverview'), t('flowTitle'), t('flowSub'), '<span class="live-pill"><i></i>' + esc(t('live')) + '</span>') +
        '<div class="flow-list">' + flow + '</div><div class="flow-footer"><span><b class="legend-dot dot-source"></b>' + esc(t('source')) + '</span><span><b class="legend-dot dot-transform"></b>' + esc(t('transform')) + '</span><span><b class="legend-dot dot-target"></b>' + esc(t('destination')) + '</span></div></section>' +
        '<section class="panel panel-health">' + sectionHead(t('healthOverview'), t('dataQuality'), t('qualityTitle'), '') +
        '<div class="score-ring" style="--score:' + Math.min(100, Number(state.metrics.qualityScore) || 0) + '"><div><strong>' + esc(global.NexusCore.number(state.metrics.qualityScore, 1)) + '</strong><small>%</small></div></div><div class="score-caption">' + esc(t('activeRules')) + '<b>' + esc(String(state.rules.filter(function (r) { return r.active; }).length)) + ' / ' + esc(String(state.rules.length)) + '</b></div><div class="quality-mini"><span>Completeness <b>98.7%</b></span><span>Freshness <b>96.4%</b></span><span>Validity <b>99.2%</b></span></div>' + button(t('evaluate'), 'evaluate-rules', '', 'btn-secondary btn-block') + '</section></div>' +
        '<div class="dashboard-grid lower-grid"><section class="panel">' + sectionHead(t('recentRuns'), t('recentRuns'), t('runsDesc'), button(t('seeRuns'), 'route', 'runs', 'btn-link')) + runTable(state.runs.slice(0, 5)) + '</section>' +
        '<section class="panel">' + sectionHead(t('activity'), t('activity'), t('prototype'), button(t('viewAll'), 'route', 'alerts', 'btn-link')) + '<div class="event-list">' + events + '</div></section></div>';
    }
    function pipelinesPage() {
      const search = String(ui.search || '').toLowerCase();
      const items = state.pipelines.filter(function (p) { return (p.name + p.id + p.domain + p.owner).toLowerCase().includes(search); });
      return sectionHead(t('pipelineTitle'), t('allPipelines'), t('pipelineDesc'), button(t('createPipeline'), 'new-pipeline', '', 'btn-primary')) +
        '<div class="toolbar"><label class="search-field"><span>⌕</span><input data-search placeholder="' + escAttr(t('searchPipelines')) + '" value="' + escAttr(ui.search || '') + '"></label><span class="toolbar-note">' + esc(String(items.length)) + ' / ' + esc(String(state.pipelines.length)) + ' workflows</span></div>' +
        '<section class="panel">' + pipelineTable(items) + '</section>';
    }
    function runsPage() {
      const search = String(ui.search || '').toLowerCase();
      const selectedStatus = ui.statusFilter || 'all';
      const items = state.runs.filter(function (run) {
        const pipeline = state.pipelines.find(function (p) { return p.id === run.pipelineId; });
        return (selectedStatus === 'all' || run.status === selectedStatus) && (run.id + (pipeline ? pipeline.name : '') + run.message).toLowerCase().includes(search);
      });
      const statusOptions = ['all', 'success', 'warning', 'failed', 'running'].map(function (s) { return '<option value="' + s + '"' + (selectedStatus === s ? ' selected' : '') + '>' + esc(t(s === 'all' ? 'allStatus' : s)) + '</option>'; }).join('');
      return sectionHead(t('runsTitle'), t('runsTitle'), t('runsDesc'), button(t('downloadCsv'), 'export-runs', '', 'btn-secondary')) +
        '<div class="toolbar"><label class="search-field"><span>⌕</span><input data-search placeholder="' + escAttr(t('searchRuns')) + '" value="' + escAttr(ui.search || '') + '"></label><select class="select-control" data-filter-status>' + statusOptions + '</select><span class="toolbar-note">' + esc(String(items.length)) + ' runs</span></div>' +
        '<section class="panel">' + runTable(items) + '</section>' +
        (ui.selectedRun ? runDetail(state, ui.selectedRun, t) : '');
    }
    function runDetail(data, id, translate) {
      const run = data.runs.find(function (r) { return r.id === id; });
      if (!run) return '';
      const pipeline = data.pipelines.find(function (p) { return p.id === run.pipelineId; });
      return '<section class="panel detail-panel"><div class="detail-heading"><div><div class="eyebrow">' + esc(translate('detail')) + ' / ' + esc(run.id) + '</div><h3>' + esc(pipeline ? pipeline.name : run.pipelineId) + '</h3></div>' + button(translate('cancel'), 'close-run', '', 'btn-quiet') + '</div><div class="detail-grid"><div><small>' + esc(translate('status')) + '</small>' + badge(run.status) + '</div><div><small>' + esc(translate('started')) + '</small><b>' + esc(global.NexusCore.time(run.startedAt)) + '</b></div><div><small>' + esc(translate('inputRecords')) + '</small><b>' + esc(global.NexusCore.number(run.recordsIn)) + '</b></div><div><small>' + esc(translate('outputRecords')) + '</small><b>' + esc(global.NexusCore.number(run.recordsOut)) + '</b></div></div><p class="run-message">' + esc(run.message) + '</p></section>';
    }
    function qualityPage() {
      const contracts = state.contracts.map(function (c) {
        return '<tr><td><div class="primary-cell"><span class="table-icon contract-icon">C</span><div><strong>' + esc(c.asset) + '</strong><small>' + esc(c.id) + ' · ' + esc(c.owner) + '</small></div></div></td><td>' + esc(c.version) + '</td><td>' + esc(String(c.fields)) + '</td><td>' + esc(global.NexusCore.number(c.score, 1)) + '%</td><td>' + badge(c.status) + '</td></tr>';
      }).join('');
      const rules = state.rules.map(function (r) {
        return '<div class="rule-row"><div class="rule-toggle-wrap"><button class="switch ' + (r.active ? 'is-on' : '') + '" data-action="toggle-rule" data-id="' + escAttr(r.id) + '" aria-label="' + escAttr(t('toggleRule')) + '"><i></i></button><span class="rule-id">' + esc(r.id) + '</span><div class="rule-name"><strong>' + esc(r.name) + '</strong><small>' + esc(r.asset) + ' · ' + esc(r.dimension) + '</small></div></div><div class="rule-stat"><strong>' + esc(global.NexusCore.number(r.passRate, 1)) + '%</strong><small>' + esc(t('passRate')) + '</small></div><div class="rule-progress"><i style="width:' + Math.min(100, r.passRate) + '%"></i></div><span class="rule-threshold">' + esc(t('threshold')) + ' ' + esc(global.NexusCore.number(r.threshold, 1)) + '%</span></div>';
      }).join('');
      return sectionHead(t('qualityTitle'), t('contracts'), t('qualityDesc'), button(t('evaluate'), 'evaluate-rules', '', 'btn-primary')) +
        '<section class="panel"><div class="panel-title"><div><h3>' + esc(t('contracts')) + '</h3><p>Versioned schemas and ownership agreements</p></div><span class="count-pill">' + esc(String(state.contracts.length)) + ' contracts</span></div><div class="table-wrap"><table><thead><tr><th>' + esc(t('asset')) + '</th><th>' + esc(t('version')) + '</th><th>' + esc(t('fields')) + '</th><th>' + esc(t('passRate')) + '</th><th>' + esc(t('status')) + '</th></tr></thead><tbody>' + contracts + '</tbody></table></div></section>' +
        '<section class="panel rules-panel"><div class="panel-title"><div><h3>' + esc(t('rules')) + '</h3><p>' + esc(t('activeRules')) + ': ' + esc(String(state.rules.filter(function (r) { return r.active; }).length)) + '</p></div><span class="count-pill">DQ / 08</span></div><div class="rules-list">' + rules + '</div></section>';
    }
    function lineagePage() {
      const selected = state.assets.find(function (a) { return a.id === ui.selectedAsset; }) || state.assets[0] || null;
      const assets = state.assets.map(function (asset) {
        return '<button class="asset-choice ' + (selected && asset.id === selected.id ? 'selected' : '') + '" data-action="select-asset" data-id="' + escAttr(asset.id) + '"><span class="asset-kind kind-' + escAttr(asset.kind.toLowerCase()) + '">' + esc(asset.kind.slice(0, 1)) + '</span><span><b>' + esc(asset.name) + '</b><small>' + esc(asset.key) + '</small></span><span class="asset-arrow">›</span></button>';
      }).join('');
      const pipeline = selected && state.pipelines.find(function (p) { return p.id === selected.pipelineId; });
      const nodes = pipeline ? pipeline.nodes : [];
      const lineage = nodes.map(function (node, index) {
        return (index ? '<div class="lineage-connector"><i></i></div>' : '') + '<div class="lineage-node"><span class="node-glyph glyph-' + escAttr(node.kind) + '">' + (node.kind === 'source' ? '◉' : node.kind === 'target' ? '▦' : '◇') + '</span><small>' + esc(t(node.kind === 'source' ? 'source' : node.kind === 'target' ? 'destination' : 'transform')) + '</small><b>' + esc(node.label) + '</b></div>';
      }).join('');
      return sectionHead(t('lineageTitle'), t('impactAnalysis'), t('lineageDesc'), '<span class="count-pill">' + esc(String(state.assets.length)) + ' assets indexed</span>') +
        '<div class="lineage-layout"><section class="panel asset-list-panel"><div class="panel-title"><div><h3>' + esc(t('catalog')) + '</h3><p>' + esc(t('lineageTip')) + '</p></div></div><div class="asset-list">' + assets + '</div></section>' +
        '<section class="panel lineage-detail"><div class="panel-title"><div><div class="eyebrow">' + esc(t('selectedAsset')) + '</div><h3>' + esc(selected ? selected.key : '') + '</h3><p>' + esc(selected ? selected.name : '') + '</p></div>' + badge(selected && pipeline ? pipeline.health : 'healthy') + '</div><div class="lineage-canvas"><div class="lineage-label">' + esc(t('upstream')) + ' → ' + esc(t('downstream')) + '</div><div class="lineage-flow">' + lineage + '</div></div><div class="impact-strip"><span><b>' + esc(selected ? selected.freshness : '—') + '</b><small>Freshness</small></span><span><b>' + esc(selected ? selected.rows : '—') + '</b><small>' + esc(t('records')) + '</small></span><span><b>' + esc(pipeline ? pipeline.id : '—') + '</b><small>' + esc(t('pipeline')) + '</small></span></div></section></div>';
    }
    function connectorsPage() {
      const cards = state.connectors.map(function (connector) {
        return '<article class="connector-card"><div class="connector-card-top"><span class="connector-logo logo-' + escAttr(connector.kind) + '">' + (connector.kind === 'source' ? '↙' : '↗') + '</span>' + badge(connector.status) + '</div><h3>' + esc(connector.name) + '</h3><p>' + esc(connector.type) + ' · ' + esc(connector.kind === 'source' ? t('source') : t('destination')) + '</p><div class="connector-meta"><span>' + esc(t('environment')) + '<b>' + esc(connector.environment) + '</b></span><span>' + esc(t('latency')) + '<b>' + esc(String(connector.latency)) + ' ms</b></span></div>' + button(t('test'), 'test-connector', connector.id, 'btn-secondary btn-block') + '</article>';
      }).join('');
      return sectionHead(t('connectorsTitle'), t('connectors'), t('connectorsDesc'), '<span class="simulated-tag">◉ ' + esc(t('mode')) + '</span>') + '<div class="connector-grid">' + cards + '</div><div class="notice-card"><span>ⓘ</span><p><b>' + esc(t('local')) + '</b><br>' + esc(t('localNote')) + '</p></div>';
    }
    function alertsPage() {
      const alerts = state.alerts.filter(function (alert) { return !ui.alertFilter || ui.alertFilter === 'all' || alert.status === ui.alertFilter; });
      const items = alerts.map(function (alert) {
        let actions = '';
        if (alert.status === 'open') actions = button(t('acknowledge'), 'ack-alert', alert.id, 'btn-mini') + button(t('resolve'), 'resolve-alert', alert.id, 'btn-mini btn-primary');
        else if (alert.status === 'acknowledged') actions = button(t('resolve'), 'resolve-alert', alert.id, 'btn-mini btn-primary');
        else actions = button(t('reopen'), 'reopen-alert', alert.id, 'btn-mini');
        return '<article class="incident-card incident-' + escAttr(alert.severity) + '"><span class="incident-severity">' + (alert.severity === 'critical' ? '!' : alert.severity === 'warning' ? '△' : 'i') + '</span><div class="incident-body"><div class="incident-title-line"><h3>' + esc(alert.title) + '</h3>' + badge(alert.status) + '</div><p>' + esc(alert.detail) + '</p><div class="incident-meta"><span>' + esc(alert.id) + '</span><span>' + esc(alert.source) + '</span><span>' + esc(alert.owner) + '</span><span>' + esc(global.NexusCore.time(alert.time)) + '</span></div></div><div class="incident-actions">' + actions + '</div></article>';
      }).join('');
      const options = ['all', 'open', 'acknowledged', 'resolved'].map(function (status) { return '<option value="' + status + '"' + ((ui.alertFilter || 'all') === status ? ' selected' : '') + '>' + esc(t(status === 'all' ? 'all' : status)) + '</option>'; }).join('');
      return sectionHead(t('alertsTitle'), t('alerts'), t('alertsDesc'), badge(String(state.alerts.filter(function (a) { return a.status !== 'resolved'; }).length) + ' open')) + '<div class="toolbar"><select class="select-control" data-alert-filter>' + options + '</select><span class="toolbar-note">' + esc(String(alerts.length)) + ' incidents</span></div><div class="incident-list">' + (items || '<div class="empty-state">' + esc(t('noAlerts')) + '</div>') + '</div>';
    }
    function catalogPage() {
      const q = String(ui.search || '').toLowerCase();
      const assets = state.assets.filter(function (a) { return (a.name + a.key + a.owner + a.kind).toLowerCase().includes(q); }).map(function (asset) {
        const pipeline = state.pipelines.find(function (p) { return p.id === asset.pipelineId; });
        return '<tr><td><div class="primary-cell"><span class="asset-kind kind-' + escAttr(asset.kind.toLowerCase()) + '">' + esc(asset.kind.slice(0, 1)) + '</span><div><strong>' + esc(asset.name) + '</strong><small>' + esc(asset.key) + '</small></div></div></td><td><span class="type-pill">' + esc(asset.kind) + '</span></td><td>' + esc(asset.rows) + '</td><td>' + esc(asset.owner) + '</td><td>' + esc(asset.freshness) + '</td><td>' + button(pipeline ? pipeline.id : t('detail'), 'route', 'lineage', 'btn-link') + '</td></tr>';
      }).join('');
      return sectionHead(t('catalogTitle'), t('catalog'), t('catalogDesc'), '<span class="count-pill">' + esc(String(state.assets.length)) + ' assets</span>') + '<div class="toolbar"><label class="search-field"><span>⌕</span><input data-search placeholder="' + escAttr(t('searchAssets')) + '" value="' + escAttr(ui.search || '') + '"></label></div><section class="panel"><div class="table-wrap"><table><thead><tr><th>' + esc(t('asset')) + '</th><th>' + esc(t('type')) + '</th><th>' + esc(t('records')) + '</th><th>' + esc(t('owner')) + '</th><th>Freshness</th><th>' + esc(t('actions')) + '</th></tr></thead><tbody>' + (assets || '<tr><td colspan="6" class="empty-cell">' + esc(t('noResults')) + '</td></tr>') + '</tbody></table></div></section>';
    }
    function settingsPage() {
      return sectionHead(t('settingsTitle'), t('settings'), t('settingsDesc'), '<span class="autosave"><i></i>' + esc(t('autosave')) + '</span>') +
        '<div class="settings-grid"><section class="panel settings-card"><div class="panel-title"><div><h3>' + esc(t('workspaceName')) + '</h3><p>' + esc(t('workspaceIntro')) + '</p></div><span class="settings-symbol">⌂</span></div><label class="field-label">' + esc(t('workspaceName')) + '<input data-setting="workspace" value="' + escAttr(state.settings.workspace) + '" maxlength="70"></label><label class="field-label">' + esc(t('language')) + '<select data-setting="language"><option value="en"' + (language === 'en' ? ' selected' : '') + '>English</option><option value="zh"' + (language === 'zh' ? ' selected' : '') + '>简体中文</option></select></label><label class="field-label">' + esc(t('retention')) + '<select data-setting="retentionDays"><option value="7">7 days</option><option value="30"' + (Number(state.settings.retentionDays) === 30 ? ' selected' : '') + '>30 days</option><option value="90">90 days</option></select></label></section>' +
        '<section class="panel settings-card"><div class="panel-title"><div><h3>' + esc(t('localOnly')) + '</h3><p>' + esc(t('localOnlyDesc')) + '</p></div><span class="settings-symbol">◉</span></div><div class="privacy-list"><span><b>01</b><span>Local-first storage<small>Browser storage only</small></span><i>✓</i></span><span><b>02</b><span>No credentials<small>' + esc(t('noConnector')) + '</small></span><i>✓</i></span><span><b>03</b><span>Portable backups<small>JSON export and import</small></span><i>✓</i></span></div></section>' +
        '<section class="panel settings-card"><div class="panel-title"><div><h3>' + esc(t('exportBackup')) + '</h3><p>' + esc(t('backupWarning')) + '</p></div><span class="settings-symbol">⇧</span></div><div class="settings-actions">' + button(t('exportBackup'), 'export-backup', '', 'btn-secondary') + button(t('importBackup'), 'import-backup', '', 'btn-secondary') + '<input type="file" id="backup-file" accept="application/json,.json" hidden>' + button(t('restoreDemo'), 'reset-workspace', '', 'btn-danger') + '</div></section>' +
        '<section class="panel settings-card about-card"><div class="eyebrow">NEXUS DATAOPS / OFFLINE EDITION</div><h3>Operational clarity, without the cloud dependency.</h3><p>' + esc(t('prototype')) + '</p><div class="about-tags"><span>v1.0.0</span><span>Vanilla JavaScript</span><span>Local storage</span><span>Zero dependencies</span></div></section></div>';
    }
    function modal() {
      const sources = state.connectors.filter(function (c) { return c.kind === 'source'; }).map(function (c) { return '<option value="' + escAttr(c.id) + '">' + esc(c.name) + '</option>'; }).join('');
      const targets = state.connectors.filter(function (c) { return c.kind === 'target'; }).map(function (c) { return '<option value="' + escAttr(c.id) + '">' + esc(c.name) + '</option>'; }).join('');
      return '<div class="modal-backdrop" data-modal hidden><form class="modal" id="pipeline-form"><div class="modal-heading"><div><div class="eyebrow">WORKFLOW DESIGNER</div><h2>' + esc(t('createPipeline')) + '</h2></div><button type="button" class="icon-button" data-action="close-modal" aria-label="' + escAttr(t('cancel')) + '">×</button></div><label class="field-label">' + esc(t('pipelineName')) + '<input name="name" required minlength="3" maxlength="80" placeholder="e.g. Product events to warehouse"></label><label class="field-label">' + esc(t('domain')) + '<input name="domain" maxlength="40" placeholder="Commerce"></label><div class="form-row"><label class="field-label">' + esc(t('selectSource')) + '<select name="source" required>' + sources + '</select></label><label class="field-label">' + esc(t('selectTarget')) + '<select name="target" required>' + targets + '</select></label></div><label class="field-label">' + esc(t('cadence')) + '<select name="cadence"><option>Manual</option><option>Every 5 min</option><option>Every 15 min</option><option>Hourly</option><option>Daily</option></select></label><div class="modal-footer">' + button(t('cancel'), 'close-modal', '', 'btn-quiet') + '<button type="submit" class="btn btn-primary">' + esc(t('create')) + ' <span>→</span></button></div></form></div>';
    }
    function navItem(key) {
      return '<button class="nav-item ' + (route === key ? 'active' : '') + '" data-action="route" data-id="' + escAttr(key) + '"><span class="nav-icon">' + icons[key] + '</span><span>' + esc(t(key)) + '</span>' + (key === 'alerts' && summary.pending ? '<em>' + esc(String(summary.pending)) + '</em>' : '') + '</button>';
    }
    const page = route === 'overview' ? overview() : route === 'pipelines' ? pipelinesPage() : route === 'runs' ? runsPage() : route === 'quality' ? qualityPage() : route === 'lineage' ? lineagePage() : route === 'connectors' ? connectorsPage() : route === 'alerts' ? alertsPage() : route === 'catalog' ? catalogPage() : settingsPage();
    return '<div class="app-shell"><aside class="sidebar"><div class="brand-lockup"><span class="brand-mark">N</span><div><strong>' + esc(t('brand')) + '</strong><small>' + esc(t('subtitle')) + '</small></div></div><div class="workspace-switch"><span class="workspace-avatar">N</span><span><small>' + esc(t('workspace')) + '</small><b>' + esc(state.settings.workspace) + '</b></span><span class="chevron">⌄</span></div><div class="nav-caption">' + esc(t('workspace')) + '</div><nav class="main-nav">' + ['overview', 'pipelines', 'runs', 'quality', 'lineage', 'connectors', 'alerts', 'catalog'].map(navItem).join('') + '</nav><div class="nav-caption nav-caption-bottom">' + esc(t('system')) + '</div><nav>' + navItem('settings') + '</nav><div class="sidebar-spacer"></div><div class="local-card"><span class="local-orbit">◉</span><div><b>' + esc(t('local')) + '</b><small>' + esc(t('offline')) + ' · zero network</small></div><i></i></div><div class="profile-row"><span class="profile-avatar">MC</span><span><b>Maya Chen</b><small>Workspace admin</small></span><span class="profile-more">···</span></div></aside><main class="main-area"><header class="topbar"><div class="breadcrumb"><span>' + esc(t('workspace')) + '</span><b>/</b><strong>' + esc(t(titleKey)) + '</strong></div><label class="global-search"><span>⌕</span><input data-search placeholder="' + escAttr(t('search')) + '" value="' + escAttr(ui.search || '') + '"><kbd>⌘ K</kbd></label><div class="top-actions"><span class="system-health"><i></i>' + esc(t('timezone')) + '</span><button class="icon-button" data-action="toggle-language" title="' + escAttr(t('language')) + '">' + (language === 'en' ? '中' : 'EN') + '</button><button class="avatar-button" title="Maya Chen">MC</button></div></header><div class="content-area"><div class="page-title"><div><div class="eyebrow">' + esc(t('overviewTag')) + '</div><h1>' + esc(route === 'overview' ? t('greeting') : t(titleKey)) + '</h1><p>' + esc(t(descKey)) + '</p></div>' + (route === 'overview' ? button(t('runAll'), 'run-all', '', 'btn-primary') : '') + '</div><div class="page-content">' + page + '</div><footer class="app-footer"><span>© 2026 Nexus DataOps</span><span>' + esc(t('prototype')) + '</span><button data-action="toggle-language">' + esc(language === 'en' ? t('chinese') : t('english')) + '</button></footer></div></main>' + modal() + '<div class="toast-region" aria-live="polite"></div></div>';
  }
  global.NexusViews = Object.freeze({ render: render, escape: esc });
})(window);
