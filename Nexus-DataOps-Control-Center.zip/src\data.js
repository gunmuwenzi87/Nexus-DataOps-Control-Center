(function (global) {
  'use strict';
  const initial = {
    schemaVersion: 1,
    settings: { workspace: 'Northstar Analytics', language: 'en', retentionDays: 30, compactTables: false },
    metrics: { qualityScore: 98.6, monthlyRuns: 12842 },
    pipelines: [
      { id: 'PL-1042', name: 'Orders CDC to Warehouse', domain: 'Commerce', owner: 'Maya Chen', source: 'orders-api', target: 'warehouse-core', cadence: 'Every 5 min', status: 'active', health: 'healthy', successRate: 99.8, avgDuration: 42, records: 18420, lastRun: '2026-10-21T10:42:18Z', lastStatus: 'success', nodes: [{ label: 'Orders API', kind: 'source' }, { label: 'Validate schema', kind: 'transform' }, { label: 'Normalize events', kind: 'transform' }, { label: 'Core warehouse', kind: 'target' }] },
      { id: 'PL-1038', name: 'Inventory Delta Stream', domain: 'Supply chain', owner: 'Noah Patel', source: 'erp-bridge', target: 'warehouse-core', cadence: 'Every 15 min', status: 'active', health: 'attention', successRate: 96.4, avgDuration: 68, records: 5281, lastRun: '2026-10-21T10:31:04Z', lastStatus: 'warning', nodes: [{ label: 'ERP change feed', kind: 'source' }, { label: 'Deduplicate SKU', kind: 'transform' }, { label: 'Join locations', kind: 'transform' }, { label: 'Inventory mart', kind: 'target' }] },
      { id: 'PL-1026', name: 'Finance Ledger Reconciliation', domain: 'Finance', owner: 'Avery Brooks', source: 'finance-ledger', target: 'finance-mart', cadence: 'Daily at 06:00', status: 'active', health: 'healthy', successRate: 100, avgDuration: 126, records: 87290, lastRun: '2026-10-21T06:02:31Z', lastStatus: 'success', nodes: [{ label: 'General ledger', kind: 'source' }, { label: 'Map account codes', kind: 'transform' }, { label: 'Reconcile totals', kind: 'transform' }, { label: 'Finance mart', kind: 'target' }] },
      { id: 'PL-1019', name: 'Customer 360 Dimensions', domain: 'Customer', owner: 'Iris Wang', source: 'crm-export', target: 'warehouse-core', cadence: 'Hourly', status: 'active', health: 'healthy', successRate: 99.2, avgDuration: 83, records: 14905, lastRun: '2026-10-21T10:00:12Z', lastStatus: 'success', nodes: [{ label: 'CRM export', kind: 'source' }, { label: 'Resolve identities', kind: 'transform' }, { label: 'Refresh segments', kind: 'transform' }, { label: 'Customer 360', kind: 'target' }] },
      { id: 'PL-1007', name: 'Quality Snapshot and SLA', domain: 'Platform', owner: 'Leo Martin', source: 'event-bus', target: 'ops-observability', cadence: 'Every 30 min', status: 'active', health: 'healthy', successRate: 99.9, avgDuration: 31, records: 1398, lastRun: '2026-10-21T10:30:55Z', lastStatus: 'success', nodes: [{ label: 'Platform event bus', kind: 'source' }, { label: 'Aggregate SLAs', kind: 'transform' }, { label: 'Score contracts', kind: 'transform' }, { label: 'Ops observability', kind: 'target' }] },
      { id: 'PL-0994', name: 'Supplier Catalog Intake', domain: 'Supply chain', owner: 'Ethan Cole', source: 'supplier-drop', target: 'catalog-staging', cadence: 'Daily at 04:30', status: 'paused', health: 'paused', successRate: 94.1, avgDuration: 94, records: 2430, lastRun: '2026-10-20T04:31:18Z', lastStatus: 'failed', nodes: [{ label: 'Supplier drop', kind: 'source' }, { label: 'Parse catalog', kind: 'transform' }, { label: 'Validate SKU map', kind: 'transform' }, { label: 'Catalog staging', kind: 'target' }] }
    ],
    runs: [
      { id: 'RUN-8921', pipelineId: 'PL-1042', status: 'success', startedAt: '2026-10-21T10:42:18Z', duration: 38, recordsIn: 18420, recordsOut: 18420, bytes: 4286000, retries: 0, quality: 100, message: 'Checkpoint committed; all contract checks passed.' },
      { id: 'RUN-8920', pipelineId: 'PL-1038', status: 'warning', startedAt: '2026-10-21T10:31:04Z', duration: 68, recordsIn: 5281, recordsOut: 5264, bytes: 1274000, retries: 1, quality: 96.4, message: '17 duplicate inventory keys quarantined for review.' },
      { id: 'RUN-8919', pipelineId: 'PL-1007', status: 'success', startedAt: '2026-10-21T10:30:55Z', duration: 31, recordsIn: 1398, recordsOut: 1398, bytes: 238000, retries: 0, quality: 100, message: 'SLA snapshot refreshed for 6 pipelines.' },
      { id: 'RUN-8918', pipelineId: 'PL-1019', status: 'success', startedAt: '2026-10-21T10:00:12Z', duration: 83, recordsIn: 14905, recordsOut: 14905, bytes: 3241000, retries: 0, quality: 99.2, message: 'Identity map refreshed; 42 new customer keys.' },
      { id: 'RUN-8917', pipelineId: 'PL-1042', status: 'success', startedAt: '2026-10-21T10:00:09Z', duration: 35, recordsIn: 17603, recordsOut: 17603, bytes: 3971000, retries: 0, quality: 100, message: 'Checkpoint committed; lag is within target.' },
      { id: 'RUN-8916', pipelineId: 'PL-1026', status: 'success', startedAt: '2026-10-21T06:02:31Z', duration: 126, recordsIn: 87290, recordsOut: 87290, bytes: 18320000, retries: 0, quality: 100, message: 'Debit and credit totals reconciled to zero variance.' },
      { id: 'RUN-8915', pipelineId: 'PL-0994', status: 'failed', startedAt: '2026-10-20T04:31:18Z', duration: 94, recordsIn: 2430, recordsOut: 2112, bytes: 861000, retries: 2, quality: 86.9, message: 'Required supplier SKU is missing in 318 rows.' },
      { id: 'RUN-8914', pipelineId: 'PL-1038', status: 'success', startedAt: '2026-10-21T10:16:02Z', duration: 59, recordsIn: 4920, recordsOut: 4920, bytes: 1148000, retries: 0, quality: 100, message: 'Inventory delta applied; no rejected rows.' }
    ],
    connectors: [
      { id: 'orders-api', name: 'Commerce Orders API', type: 'REST API', kind: 'source', status: 'connected', environment: 'Sandbox fixture', latency: 42 },
      { id: 'erp-bridge', name: 'ERP Change Feed', type: 'Webhook', kind: 'source', status: 'connected', environment: 'Local fixture', latency: 68 },
      { id: 'finance-ledger', name: 'General Ledger Snapshot', type: 'CSV / File', kind: 'source', status: 'connected', environment: 'Sample data', latency: 126 },
      { id: 'crm-export', name: 'CRM Customer Export', type: 'CSV / File', kind: 'source', status: 'connected', environment: 'Sample data', latency: 83 },
      { id: 'event-bus', name: 'Platform Event Bus', type: 'Event stream', kind: 'source', status: 'connected', environment: 'In-memory simulator', latency: 31 },
      { id: 'supplier-drop', name: 'Supplier Catalog Drop', type: 'SFTP / File', kind: 'source', status: 'attention', environment: 'Offline fixture', latency: 94 },
      { id: 'warehouse-core', name: 'Core Warehouse', type: 'Warehouse', kind: 'target', status: 'connected', environment: 'Local simulator', latency: 12 },
      { id: 'finance-mart', name: 'Finance Mart', type: 'Warehouse', kind: 'target', status: 'connected', environment: 'Local simulator', latency: 18 },
      { id: 'catalog-staging', name: 'Catalog Staging', type: 'Object storage', kind: 'target', status: 'connected', environment: 'Local simulator', latency: 22 },
      { id: 'ops-observability', name: 'Ops Observability', type: 'Local index', kind: 'target', status: 'connected', environment: 'Local simulator', latency: 9 }
    ],
    contracts: [
      { id: 'CT-021', asset: 'commerce.orders', owner: 'Commerce data', version: 'v3.2', fields: 24, rules: 4, score: 99.8, status: 'healthy' },
      { id: 'CT-018', asset: 'supply.inventory_delta', owner: 'Supply chain', version: 'v2.1', fields: 18, rules: 5, score: 96.4, status: 'attention' },
      { id: 'CT-014', asset: 'finance.general_ledger', owner: 'Finance systems', version: 'v1.8', fields: 32, rules: 6, score: 100, status: 'healthy' },
      { id: 'CT-009', asset: 'customer.profile', owner: 'Customer analytics', version: 'v4.0', fields: 41, rules: 7, score: 99.2, status: 'healthy' },
      { id: 'CT-006', asset: 'supplier.catalog', owner: 'Procurement', version: 'v1.4', fields: 18, rules: 5, score: 86.9, status: 'critical' }
    ],
    rules: [
      { id: 'DQ-101', name: 'Order key is unique', asset: 'commerce.orders', dimension: 'Uniqueness', severity: 'critical', passRate: 100, checked: 18420, threshold: 99.9, active: true },
      { id: 'DQ-102', name: 'Order total is non-negative', asset: 'commerce.orders', dimension: 'Validity', severity: 'high', passRate: 99.98, checked: 18420, threshold: 99.5, active: true },
      { id: 'DQ-118', name: 'Inventory delta has a SKU', asset: 'supply.inventory_delta', dimension: 'Completeness', severity: 'critical', passRate: 98.7, checked: 5264, threshold: 99, active: true },
      { id: 'DQ-121', name: 'Inventory event is recent', asset: 'supply.inventory_delta', dimension: 'Freshness', severity: 'medium', passRate: 96.4, checked: 5264, threshold: 95, active: true },
      { id: 'DQ-204', name: 'Debit and credit reconcile', asset: 'finance.general_ledger', dimension: 'Consistency', severity: 'critical', passRate: 100, checked: 87290, threshold: 100, active: true },
      { id: 'DQ-311', name: 'Customer email format', asset: 'customer.profile', dimension: 'Validity', severity: 'medium', passRate: 99.2, checked: 14905, threshold: 98, active: true },
      { id: 'DQ-402', name: 'Supplier SKU is present', asset: 'supplier.catalog', dimension: 'Completeness', severity: 'critical', passRate: 86.9, checked: 2430, threshold: 99, active: true },
      { id: 'DQ-408', name: 'Supplier currency is supported', asset: 'supplier.catalog', dimension: 'Validity', severity: 'high', passRate: 100, checked: 2112, threshold: 99, active: false }
    ],
    alerts: [
      { id: 'ALT-2081', title: 'Inventory delta contains duplicate keys', detail: '17 rows were quarantined during the latest run.', severity: 'warning', source: 'PL-1038 / RUN-8920', time: '2026-10-21T10:32:12Z', status: 'open', owner: 'Noah Patel' },
      { id: 'ALT-2078', title: 'Supplier catalog contract below threshold', detail: 'Required SKU field is missing in 13.1% of sampled rows.', severity: 'critical', source: 'CT-006 / DQ-402', time: '2026-10-20T04:32:52Z', status: 'acknowledged', owner: 'Ethan Cole' },
      { id: 'ALT-2074', title: 'Supplier intake has been paused', detail: 'Pipeline remains disabled pending a source mapping review.', severity: 'warning', source: 'PL-0994', time: '2026-10-20T04:33:00Z', status: 'open', owner: 'Ethan Cole' },
      { id: 'ALT-2061', title: 'Finance reconciliation completed', detail: 'Debit / credit variance is zero for the latest snapshot.', severity: 'info', source: 'PL-1026 / RUN-8916', time: '2026-10-21T06:04:37Z', status: 'resolved', owner: 'Avery Brooks' }
    ],
    assets: [
      { id: 'A-01', name: 'Commerce Orders API', key: 'raw.commerce.orders', kind: 'Source', rows: '18.4K / run', owner: 'Commerce data', pipelineId: 'PL-1042', freshness: '42 sec' },
      { id: 'A-02', name: 'Normalized Orders', key: 'core.commerce.orders', kind: 'Table', rows: '2.8M total', owner: 'Platform', pipelineId: 'PL-1042', freshness: '5 min' },
      { id: 'A-03', name: 'Orders by Day', key: 'mart.commerce.orders_daily', kind: 'Model', rows: '365 partitions', owner: 'Analytics', pipelineId: 'PL-1042', freshness: '6 min' },
      { id: 'A-04', name: 'ERP Inventory Delta', key: 'raw.supply.inventory_delta', kind: 'Source', rows: '5.3K / run', owner: 'Supply chain', pipelineId: 'PL-1038', freshness: '11 min' },
      { id: 'A-05', name: 'Inventory by Site', key: 'mart.supply.inventory_site', kind: 'Model', rows: '148K total', owner: 'Operations', pipelineId: 'PL-1038', freshness: '17 min' },
      { id: 'A-06', name: 'General Ledger Snapshot', key: 'raw.finance.general_ledger', kind: 'Source', rows: '87.3K / run', owner: 'Finance systems', pipelineId: 'PL-1026', freshness: '4 hr' },
      { id: 'A-07', name: 'Daily Trial Balance', key: 'mart.finance.trial_balance', kind: 'Model', rows: '14.2K total', owner: 'Finance', pipelineId: 'PL-1026', freshness: '4 hr' },
      { id: 'A-08', name: 'Customer Profile', key: 'core.customer.profile', kind: 'Table', rows: '322K total', owner: 'Customer analytics', pipelineId: 'PL-1019', freshness: '56 min' }
    ],
    events: [
      { id: 'EV-8912', kind: 'success', text: 'Orders CDC committed 18,420 records', meta: 'PL-1042 / 38 sec / 10:42 AM' },
      { id: 'EV-8911', kind: 'warning', text: '17 inventory keys moved to quarantine', meta: 'PL-1038 / 68 sec / 10:32 AM' },
      { id: 'EV-8910', kind: 'success', text: 'Data quality snapshot refreshed', meta: 'PL-1007 / 31 sec / 10:31 AM' },
      { id: 'EV-8909', kind: 'success', text: 'Customer dimension published', meta: 'PL-1019 / 83 sec / 10:00 AM' }
    ]
  };
  global.NexusData = Object.freeze({ initial });
})(window);
