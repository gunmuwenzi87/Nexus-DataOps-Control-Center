(function (global) {
  'use strict';
  function boot() {
    const root = document.getElementById('app');
    if (!root || !global.NexusCore || !global.NexusViews) return;
    let storage;
    try {
      storage = global.localStorage;
      storage.setItem('__nexus_probe__', '1');
      storage.removeItem('__nexus_probe__');
    } catch (_) {
      const memory = Object.create(null);
      storage = { getItem: function (key) { return memory[key] || null; }, setItem: function (key, value) { memory[key] = value; }, removeItem: function (key) { delete memory[key]; } };
    }
    let state = global.NexusCore.load(storage);
    const routeNames = ['overview', 'pipelines', 'runs', 'quality', 'lineage', 'connectors', 'alerts', 'catalog', 'settings'];
    const fromHash = function () {
      const route = location.hash.replace(/^#\/?/, '');
      return routeNames.includes(route) ? route : 'overview';
    };
    const ui = { route: fromHash(), search: '', statusFilter: 'all', alertFilter: 'all', selectedAsset: state.assets[0] && state.assets[0].id, selectedRun: null };
    const runTimers = new Map();
    let toastTimer = 0;
    let saving = false;
    function tr(key) { return global.NexusI18n.translate(state.settings.language, key); }
    function errorText(error) {
      const message = error instanceof Error ? error.message : String(error);
      if (state.settings.language !== 'zh') return message;
      if (message.includes('paused')) return '该管道已暂停，请先恢复后再运行。';
      if (message.includes('already in progress')) return '该管道已有一项运行任务正在执行。';
      if (message.includes('at least 3 characters')) return '管道名称至少需要 3 个字符。';
      if (message.includes('source and destination')) return '请选择可用的数据源和目标端。';
      return '操作未能完成：' + message;
    }
    function notify(message, tone) {
      const region = root.querySelector('.toast-region');
      if (!region) return;
      region.innerHTML = '<div class="toast toast-' + (tone || 'success') + '"><span>' + (tone === 'error' ? '!' : '✓') + '</span>' + global.NexusViews.escape(message) + '</div>';
      global.clearTimeout(toastTimer);
      toastTimer = global.setTimeout(function () { if (region.isConnected) region.innerHTML = ''; }, 3200);
    }
    function persist(showError) {
      if (saving) return;
      saving = true;
      try {
        global.NexusCore.save(storage, state);
      } catch (_) {
        if (showError !== false) notify(tr('storageError'), 'error');
      } finally { saving = false; }
    }
    function render() {
      const active = document.activeElement;
      const isSearch = active && active.hasAttribute('data-search');
      const selection = isSearch && typeof active.selectionStart === 'number' ? active.selectionStart : null;
      root.innerHTML = global.NexusViews.render(state, ui);
      if (isSearch) {
        const replacement = root.querySelector('[data-search]');
        if (replacement) {
          replacement.focus({ preventScroll: true });
          if (selection !== null) replacement.setSelectionRange(selection, selection);
        }
      }
    }
    function setRoute(route) {
      if (!routeNames.includes(route)) route = 'overview';
      ui.route = route;
      ui.search = '';
      ui.selectedRun = null;
      if (location.hash !== '#/' + route) location.hash = '/' + route;
      render();
    }
    function finishLater(runId) {
      const delay = 900 + Math.floor(Math.random() * 900);
      const timer = global.setTimeout(function () {
        runTimers.delete(runId);
        try {
          const run = global.NexusCore.finishRun(state, runId);
          persist();
          render();
          notify(run.status === 'failed' ? tr('runFailed') : tr('runFinished'), run.status === 'failed' ? 'error' : run.status === 'warning' ? 'warning' : 'success');
        } catch (error) { notify(errorText(error), 'error'); }
      }, delay);
      runTimers.set(runId, timer);
    }
    function startPipeline(id) {
      try {
        const run = global.NexusCore.startRun(state, id);
        persist();
        render();
        notify(tr('runStarted'));
        finishLater(run.id);
      } catch (error) { notify(errorText(error), 'error'); }
    }
    function startAll() {
      if (!global.confirm(tr('runAllConfirm'))) return;
      state.pipelines.filter(function (pipeline) { return pipeline.status === 'active' && !state.runs.some(function (run) { return run.pipelineId === pipeline.id && run.status === 'running'; }); }).forEach(function (pipeline) {
        try {
          const run = global.NexusCore.startRun(state, pipeline.id);
          finishLater(run.id);
        } catch (error) { notify(errorText(error), 'error'); }
      });
      persist();
      render();
      notify(tr('runStarted'));
    }
    function updateAlert(id, status) {
      const alert = state.alerts.find(function (item) { return item.id === id; });
      if (!alert) return;
      alert.status = status;
      global.NexusCore.addEvent(state, 'info', alert.id + ' updated', status);
      persist(); render(); notify(tr('alertUpdated'));
    }
    root.addEventListener('click', function (event) {
      const target = event.target.closest('[data-action]');
      if (!target) return;
      const action = target.dataset.action;
      const id = target.dataset.id;
      if (action === 'route') { setRoute(id); return; }
      if (action === 'run-pipeline') { startPipeline(id); return; }
      if (action === 'run-all') { startAll(); return; }
      if (action === 'toggle-pipeline') {
        const pipeline = state.pipelines.find(function (item) { return item.id === id; });
        if (!pipeline) return;
        pipeline.status = pipeline.status === 'active' ? 'paused' : 'active';
        pipeline.health = pipeline.status === 'active' ? (pipeline.lastStatus === 'failed' ? 'attention' : 'healthy') : 'paused';
        global.NexusCore.addEvent(state, 'info', pipeline.name + (pipeline.status === 'active' ? ' resumed' : ' paused'), pipeline.id);
        persist(); render(); notify(tr(pipeline.status === 'active' ? 'enabled' : 'disabled')); return;
      }
      if (action === 'new-pipeline') { const modal = root.querySelector('[data-modal]'); if (modal) { modal.hidden = false; const field = modal.querySelector('[name="name"]'); if (field) field.focus(); } return; }
      if (action === 'close-modal') { const modal = root.querySelector('[data-modal]'); if (modal) modal.hidden = true; return; }
      if (action === 'evaluate-rules') {
        const result = global.NexusCore.evaluateRules(state);
        persist(); render();
        notify(tr('rulesDone') + ' · ' + result.passed + ' passed / ' + result.failed + ' below threshold', result.failed ? 'warning' : 'success'); return;
      }
      if (action === 'toggle-rule') {
        const rule = state.rules.find(function (item) { return item.id === id; });
        if (rule) {
          rule.active = !rule.active;
          const activeRules = state.rules.filter(function (item) { return item.active; });
          state.metrics.qualityScore = activeRules.length ? activeRules.reduce(function (sum, item) { return sum + item.passRate; }, 0) / activeRules.length : 0;
          persist(); render();
        }
        return;
      }
      if (action === 'select-asset') { ui.selectedAsset = id; render(); return; }
      if (action === 'open-run') { ui.selectedRun = id; ui.route = 'runs'; ui.search = ''; if (location.hash !== '#/runs') location.hash = '/runs'; render(); return; }
      if (action === 'close-run') { ui.selectedRun = null; render(); return; }
      if (action === 'ack-alert') { updateAlert(id, 'acknowledged'); return; }
      if (action === 'resolve-alert') { updateAlert(id, 'resolved'); return; }
      if (action === 'reopen-alert') { updateAlert(id, 'open'); return; }
      if (action === 'test-connector') {
        const connector = state.connectors.find(function (item) { return item.id === id; });
        if (connector) { connector.lastCheck = new Date().toISOString(); global.NexusCore.addEvent(state, 'success', connector.name + ' check completed (simulated)', connector.latency + ' ms'); persist(); render(); notify(tr('testDone')); }
        return;
      }
      if (action === 'toggle-language') { state.settings.language = state.settings.language === 'en' ? 'zh' : 'en'; persist(); render(); return; }
      if (action === 'export-backup') {
        try { global.NexusCore.download('nexus-workspace-backup.json', JSON.stringify(state, null, 2)); notify(tr('exported')); } catch (_) { notify(tr('storageError'), 'error'); }
        return;
      }
      if (action === 'export-runs') {
        const rows = [['run_id', 'pipeline_id', 'status', 'started_at', 'duration_seconds', 'records_in', 'records_out', 'quality', 'message']].concat(state.runs.map(function (run) { return [run.id, run.pipelineId, run.status, run.startedAt, run.duration, run.recordsIn, run.recordsOut, run.quality, run.message]; }));
        const csv = rows.map(function (row) { return row.map(function (cell) { return '"' + String(cell == null ? '' : cell).replace(/"/g, '""') + '"'; }).join(','); }).join('\r\n');
        global.NexusCore.download('nexus-run-history.csv', '\uFEFF' + csv, 'text/csv;charset=utf-8'); return;
      }
      if (action === 'import-backup') { const input = root.querySelector('#backup-file'); if (input) input.click(); return; }
      if (action === 'reset-workspace') {
        if (!global.confirm(tr('confirmReset'))) return;
        runTimers.forEach(function (timer) { global.clearTimeout(timer); }); runTimers.clear();
        state = global.NexusCore.clone(global.NexusData.initial);
        ui.route = 'overview'; ui.search = ''; ui.selectedAsset = state.assets[0].id; ui.selectedRun = null;
        persist(); render(); notify(tr('reset')); return;
      }
    });
    root.addEventListener('input', function (event) {
      if (event.target.matches('[data-search]')) {
        ui.search = event.target.value;
        const other = Array.from(root.querySelectorAll('[data-search]')).find(function (input) { return input !== event.target; });
        if (other) other.value = ui.search;
        const cursor = event.target.selectionStart;
        render();
        const field = root.querySelector('[data-search]');
        if (field) { field.focus({ preventScroll: true }); field.setSelectionRange(cursor, cursor); }
      }
      if (event.target.matches('[data-setting="workspace"]')) { state.settings.workspace = event.target.value; persist(false); }
    });
    root.addEventListener('change', function (event) {
      if (event.target.matches('[data-filter-status]')) { ui.statusFilter = event.target.value; render(); return; }
      if (event.target.matches('[data-alert-filter]')) { ui.alertFilter = event.target.value; render(); return; }
      if (event.target.matches('[data-setting="language"]')) { state.settings.language = event.target.value; persist(); render(); return; }
      if (event.target.matches('[data-setting="retentionDays"]')) { state.settings.retentionDays = Number(event.target.value); persist(); return; }
      if (event.target.matches('#backup-file')) {
        const file = event.target.files && event.target.files[0];
        if (!file) { notify(tr('noFiles'), 'warning'); return; }
        const reader = new FileReader();
        reader.onload = function () {
          try {
            const restored = global.NexusCore.migrate(JSON.parse(String(reader.result || '')));
            state = restored;
            ui.selectedAsset = state.assets[0] && state.assets[0].id;
            ui.route = fromHash();
            persist(); render(); notify(tr('imported'));
          } catch (_) { notify(tr('invalidImport'), 'error'); }
          event.target.value = '';
        };
        reader.onerror = function () { notify(tr('invalidImport'), 'error'); event.target.value = ''; };
        reader.readAsText(file);
      }
    });
    root.addEventListener('submit', function (event) {
      if (event.target.id !== 'pipeline-form') return;
      event.preventDefault();
      const form = new FormData(event.target);
      try {
        global.NexusCore.createPipeline(state, { name: form.get('name'), domain: form.get('domain'), source: form.get('source'), target: form.get('target'), cadence: form.get('cadence') });
        ui.route = 'pipelines'; ui.search = '';
        persist(); render(); notify(tr('created'));
      } catch (error) { notify(errorText(error), 'error'); }
    });
    root.addEventListener('keydown', function (event) {
      if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'k') { event.preventDefault(); const field = root.querySelector('.global-search input'); if (field) field.focus(); }
      if (event.key === 'Escape') { const modal = root.querySelector('[data-modal]'); if (modal) modal.hidden = true; ui.selectedRun = null; render(); }
    });
    const onHashChange = function () {
      ui.route = fromHash();
      ui.search = '';
      if (ui.route !== 'runs') ui.selectedRun = null;
      render();
    };
    const onRuntimeError = function (event) {
      notify(state.settings.language === 'zh' ? '页面发生意外错误，请刷新后重试。' : 'An unexpected page error occurred. Refresh and try again.', 'error');
      if (event && event.preventDefault) event.preventDefault();
    };
    const onUnhandledRejection = function () {
      notify(state.settings.language === 'zh' ? '有一项后台操作未能完成。' : 'A background operation could not be completed.', 'error');
    };
    global.addEventListener('hashchange', onHashChange);
    global.addEventListener('error', onRuntimeError);
    global.addEventListener('unhandledrejection', onUnhandledRejection);
    global.addEventListener('pagehide', function () {
      runTimers.forEach(function (timer) { global.clearTimeout(timer); });
      runTimers.clear();
      global.clearTimeout(toastTimer);
      global.removeEventListener('hashchange', onHashChange);
      global.removeEventListener('error', onRuntimeError);
      global.removeEventListener('unhandledrejection', onUnhandledRejection);
    }, { once: true });
    if (!location.hash) location.hash = '/overview';
    render();
    if (state.loadWarning) notify(tr('invalidImport'), 'warning');
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot, { once: true });
  else boot();
})(window);
